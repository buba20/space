### Prepare environment 
 - Install kind server 
 - run ./kind-config/kind-with-registry.sh, so it will create and setup test cluster.
 - Scripts contain local docker registry configuration.

#### Docker image 
 - In the root directory, there is a Docker file that will create an image that will be visible in new cluster.
 - To execute an image on our cluster, first we need tp build image and push it to local registry.
   Let's assume that we want to create a simple image that logs message on console and go to sleep.
 
   Dockerfile: 
``` Dockerfile
FROM debian:buster-slim
CMD echo "Hello World!" && sleep 360
```
  Build cmd: 
``` shell
docker build . -t localhost:5000/sleepy:latest
```
`localhost:5000` specify location of our local image registry. 

Push our image to local registry: 
```shell
docker push localhost:5000/sleepy:latest 
```
Let's test if application will run on out cluster:
```shell
kubectl create deployment hello-sleepy --image=localhost:5000/sleepy:latest
```
We should see `Hello World!` after checking logs for created deployment/pod.

### Non-prod setup
#### Grafana Prometheus

To speed up work, I used the [`Bitnami Kubeapps`](https://kubeapps.dev/) tool to install Prometheus, Mimir, Grafana. 
After running a few steps from the website, we have access to the entire catalog of applications. 
Select one, provide configuration and deploy.

####  Grafana Mimir

An open source time series
database that helps you scale
to one billion metrics and beyond.
 - Multi-tenancy
 - High availability
 - Horizontal scalability
 - Ease of use
 - Best-in-class performance

##### Running Grafana Mimir (Dev)

>**Warning**: 
Grafana Mimir includes a system that optionally and **anonymously reports non-sensitive, non-personally identifiable** 
information about the running Mimir cluster to a remote statistics server. 
Mimir maintainers use this anonymous information to learn more about how the open source community 
runs Mimir and what the Mimir team should focus on when working on the next features and documentation improvements.
More here: https://grafana.com/docs/mimir/latest/configure/about-anonymous-usage-statistics-reporting/


Can be deployed in the following modes 
 - Distributed (microservice mode) from Helm, Jsonnet, Binaries 
 - Monolithic from Binaries

> **Warning!**
After I deploy service for the first time, I struggle with sending any metrics from Prometheus to Mimir.
I keep getting a log message on Prometheus pods that `connection refused`. 
Solution for that was disabling multi-tenancy in configuration: `multitenancy_enabled: false` (Mimir config-map).

> In case that we want to keep this configuration, 
Prometheus must send additional header with `X-Scope-OrgID: TenanatName`.
Tenant name has its own limitations more about it here: https://grafana.com/docs/mimir/latest/configure/about-tenant-ids/ 

With Kubeapps dashboard, we select Grafana Mimir deployment. 
Unfortunately, a configuration section is just a flat file with over 2K lines. 
So lets focus only on updating configuration for object store. Because this is just a 
POC and I don't have access to any of the supported cloud storage, I will fall back to file-system. 
In the config file, there are a few places that we need to update because the default option is Minio(S3 provider).
After executing the script, we should see that all the pods are running.

> Grafana prepares also instruction to hot to run Mimir on docker without a need for running Kubernetes Cluster. 
[Getting started with Mimir]('https://grafana.com/docs/mimir/latest/get-started/').

>In case that we don't have access to any supported cloud object store, we can configure Mimir to use a file system instead.
[File system configuration](https://grafana.com/docs/mimir/latest/references/configuration-parameters/#filesystem_storage_backend)
 

##### All components in place
| NAMESPACE|            NAME                                               | READY | STATUS  | AGE    |
|----------|---------------------------------------------------------------|-------|---------|--------|
| default  |            metrics-generator-78b7b4ffc6-vb5bk                 | 1/1   | Running | 20h    |
| default  |            mimir-grafana-mimir-compactor-0                    | 1/1   | Running | 3m51s  |
| default  |            mimir-grafana-mimir-distributor-97468757b-wfnj8    | 1/1   | Running | 3m51s  |
| default  |            mimir-grafana-mimir-gateway-68d9d8bbc5-5sv8l       | 1/1   | Running | 3m51s  |
| default  |            mimir-grafana-mimir-ingester-0                     | 1/1   | Running | 3m51s  |
| default  |            mimir-grafana-mimir-ingester-1                     | 1/1   | Running | 2m     |
| default  |            mimir-grafana-mimir-querier-7f6c584998-j9zjk       | 1/1   | Running | 3m51s  |
| default  |            mimir-grafana-mimir-query-frontend-78d7c759cf-48clx| 1/1   | Running | 3m51s  |
| default  |            mimir-grafana-mimir-store-gateway-0                | 1/1   | Running | 3m51s  |
| default  |            mimir-memcachedchunks-0                            | 1/1   | Running | 3m51s  |
| default  |            mimir-memcachedfrontend-0                          | 1/1   | Running | 3m51s  |
| default  |            mimir-memcachedindex-0                             | 1/1   | Running | 3m51s  |
| default  |            mimir-memcachedmetadata-0                          | 1/1   | Running | 3m51s  |
| default  |            prometheus-server-5964b8b8cd-jrgg8                 | 1/1   | Running | 115m   |


#### Configure Prometheus remote write

Extend prometheus.yaml configuration with information where it should send metrics.
Add `remote_write` with url to Mimir gateway instance.
```yaml
global:
  external_labels:
    monitor: prometheus
remote_write:
  - url: 'http://mimir-grafana-mimir-gateway.default.svc.cluster.local:80/api/v1/push'
scrape_configs:
  - job_name: "kubernetes-pods"
```

> Tip: 
Mimir documentation suggests adding this header
`X-Prometheus-Remote-Write-Version: 0.1.0`

#### Configure dataset in Grafana
Login to Grafana and add new Prometheus datasource. Paste link to Mimir gateway.
For it is: `http://mimir-grafana-mimir-gateway.default.svc.cluster.local/prometheus`.
Done, now we can build our dashboard and alerting.

### Mimir HA 
With Mimir in place, we can make use of high-availability, thanks to build-in feature to deduplicate metrics.
Don't have time to simulate it, however, it allows to configure to Prometheus servers/agent to send the same metrics 
to single Mimir instance and Mimir with select just on of them to store.

More about this feature: https://grafana.com/docs/mimir/latest/configure/configure-high-availability-deduplication/.

### Grafana Mimir zone-aware replication
Zone-aware replication is the replication of data across failure domains.
Zone-aware replication helps to avoid data loss during a domain outage. Grafana Mimir defines failure domains as zones. Depending on the underlying infrastructure that Grafana Mimir is deployed on, zones could be, for example,
- Availability zones
- Data centers
- Racks
- Anti-affinity groups within a single availability zone

More about this feature: https://grafana.com/docs/mimir/latest/configure/configure-zone-aware-replication/.