Given the list from the main migration status page:
1.	Using Azure DevOps for CI
2.	Using shared toolset (Arcade SDK)
3.	Engineering dependency flow
4.	Internal builds from dnceng

Corefx 
1.	End of Nov (1, 3 and 4 are tracked here)
2.	Mid Nov (to required level - further progress through Dec). Tracked here
3.	End of Nov. Currently we have incoming but not yet outgoing
4.	With 3.

standard
1.	Mid Nov
2.	Mid Nov
3.	Mid Nov
4.	Mid Nov

Core-setup
Ownership thread needs to be resolved.

from @danmosemsft on 10/29
