﻿using System;

namespace ClassLib1
{
    public class Class1
    {
    }
}
