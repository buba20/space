﻿using System;

namespace Always
{
    public class Class1
    {
    }
}
