﻿using System;

namespace Maybe
{
    public class Class1
    {
    }
}
