# Microsoft.DotNet.Build.Tasks.Feed

Task package which handles uploading packages or files to an Azure blob storage account and creating / managing the blob storage container so that it can act as a restorable NuGet package feed

See comment header in [Microsoft.DotNet.Build.Tasks.Feed.targets](build/Microsoft.DotNet.Build.Tasks.Feed.targets) for usage.