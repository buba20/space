# Utility scripts for Arcade

This folder is intended to contain utility scripts for doing simple tasks