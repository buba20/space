---
name: Default Arcade Issue Template
about: Used by Arcade as the default issue template
title: ''
labels: ''
assignees: ''

---

<!-- If these statements apply, replace [ ] with [x] before filing your issue. -->
- [ ] This issue is blocking <!-- Describe below what is blocked. -->
- [ ] This issue is causing unreasonable pain

<!-- Write your issue description below. -->
