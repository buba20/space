Given the list from the main migration status page:
1.	Using Azure DevOps for CI
2.	Using shared toolset (Arcade SDK)
3.	Engineering dependency flow
4.	Internal builds from dnceng

aspnet/WebSDK (https://github.com/aspnet/websdk)
1.	Completed
2.	Completed
3.	Completed
4.	Completed

dotnet/Templating (https://github.com/dotnet/templating)
1.	Completed
2.	Week of 12/24
3.	End of December - There is not much work here for templating. Just need to flow the Package versions to the cli toolset.
4.	End of December

Now that the WebSdk is migrated completely, it should be much easier to complete dotnet/templating.

@Joeloff will be doing the work for both dotnet/Templating & aspnet/WebSDK

from @vijayrkn on 12/21/2018
