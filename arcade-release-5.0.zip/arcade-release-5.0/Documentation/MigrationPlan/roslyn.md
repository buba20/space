Given the list from the main migration status page:
1.	Using Azure DevOps for CI
1.	Using shared toolset (Arcade SDK)
1.	Engineering dependency flow
1.	Internal builds from dnceng

Roslyn 
1.	Complete as soon as VS2017 machines available 
1.	End of November. Remaining work known
1.	Will fall out from arcade work
1.	N/A
